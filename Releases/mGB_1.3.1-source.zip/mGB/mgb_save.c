#include <types.h>

UBYTE saveData[513];
