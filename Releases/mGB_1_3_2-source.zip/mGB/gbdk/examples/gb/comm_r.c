#include <gb/gb.h>
#include <stdio.h>

const char * str = "Hello World!";
char buffer[32];

UBYTE midiDataReadPosition;
UBYTE midiDataWritePosition;
extern UBYTE midiData[256];
unsigned int r;

void main(void)
{

  puts("Fucko");

  while(1) {
  _io_out = 0x00;
  send_byte();
  if(midiDataReadPosition != midiDataWritePosition) {
	midiDataReadPosition++;
	r = midiData[midiDataReadPosition]&0x7Fu;
	//printf(":%s", (UBYTE) midiData[midiDataReadPosition]);
	if(r) {
		printf("-%d",(r));
	}
  }
  }
}
