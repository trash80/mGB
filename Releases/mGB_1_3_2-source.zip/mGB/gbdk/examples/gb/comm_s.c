#include <gb/gb.h>
#include <stdio.h>

const char * str = "Hello World!";
char buffer[32];

UBYTE midiDataReadPosition;
UBYTE midiDataWritePosition;
extern UBYTE midiData[256];
unsigned int r;
UBYTE d;

void catch_midi()
{
	if(midiDataReadPosition != midiDataWritePosition) {
		_io_out = midiData[midiDataReadPosition];
		send_byte();
		midiDataReadPosition++;
	}
}

void add_so(UBYTE i)
{
	if(_io_status == IO_IDLE) {
		_io_out = i;
		send_byte();
	} else {
		midiData[midiDataWritePosition] = i;
		midiDataWritePosition++;
	}
}

void tim()
{
	d++;
	add_so(d);
}


void main(void)
{
  disable_interrupts();
  add_SIO(catch_midi);
  add_TIM(tim);
  enable_interrupts();
  /* Set TMA to divide clock by 0x100 */
  TMA_REG = 0x00U;
  /* Set clock to 1096 Hertz */
  TAC_REG = 0x04U;
  
  set_interrupts(SIO_IFLAG|TIM_IFLAG|VBL_IFLAG|LCD_IFLAG);
  
  puts("Sendo");
  
  while(1) {
	
  }
}

