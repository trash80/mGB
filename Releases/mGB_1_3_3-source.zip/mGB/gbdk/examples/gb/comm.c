#include <gb/gb.h>
#include <stdio.h>

const char * str = "Hello World!";
char buffer[32];

UBYTE midiDataReadPosition;
UBYTE midiDataWritePosition;
extern UBYTE midiData[256];
unsigned int r;

void main(void)
{

  puts("Fucko");

  while(1) {

  if(midiDataReadPosition != midiDataWritePosition) {
	midiDataReadPosition++;
	r = midiData[midiDataReadPosition];
	//printf(":%s", (UBYTE) midiData[midiDataReadPosition]);
	printf("-%d",(r));
  }
  }
}
