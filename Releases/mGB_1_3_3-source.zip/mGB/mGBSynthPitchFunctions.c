void setPitchBendFrequencyOffset(UBYTE synth,UBYTE synth_pitch,UBYTE synth_note_range)
{
	//freq of note status, freq of pb note range high, freq of pb note range low, pbwheel in
	systemIdle = 0;

	if(synth != NOI) {
		UWORD * f =& freq[noteStatus[synth_pitch]];

		if(pbWheelIn[synth] & 0x80) {
			UWORD *fp =& freq[pbNoteRange[synth_note_range+1]];
			currentFreq = pbWheelIn[synth] - 0x7F;
			currentFreq = (currentFreq<<6) / 0x80;
			currentFreq = ((*fp) - (*f)) * currentFreq;
			currentFreq = (*f) + (currentFreq>>6);
		} else {
			UWORD *fp =& freq[pbNoteRange[synth_note_range]];
			currentFreq = (*f) - (((((UWORD) (0x80 - pbWheelIn[synth]))<<6) / 0x80) * ((*f) - (*fp))>>6);
		}
		switch(synth) {
			case PU1:
				NR14_REG = (currentFreq>>8U);
				NR13_REG = currentFreq;
				currentFreqData[PU1] = currentFreq;
				break;
			case PU2:
				NR24_REG = (currentFreq>>8U);
				NR23_REG = currentFreq;
				currentFreqData[PU2] = currentFreq;
				break;
			default:
				NR34_REG = (currentFreq>>8U);
				NR33_REG = currentFreq;
				wavCurrentFreq = currentFreq;
				currentFreqData[WAV] = currentFreq;
		}

	} else {
		if(pbWheelIn[NOI] & 0x80) {
		    noteStatus[NOI_CURRENT_NOTE] = noteStatus[NOI_CURRENT_NOTE];
			currentFreq = noiFreq[noteStatus[NOI_CURRENT_NOTE] + ((pbWheelIn[NOI] - 0x80) >>3)];
		} else {
		    noteStatus[NOI_CURRENT_NOTE] = noteStatus[NOI_CURRENT_NOTE];
			currentFreq = noiFreq[noteStatus[NOI_CURRENT_NOTE] - ((0x80 - pbWheelIn[NOI]) >>3)];
		}
		NR43_REG = currentFreq;
		currentFreqData[NOI] = currentFreq;
	}
}

void addVibrato(UBYTE synth){
	if(vibratoDepth[synth]) {
		currentFreq = currentFreqData[synth] + vibratoPosition[synth];
		pbWheelInLast[synth] = PBWHEEL_CENTER;
		if(synth == PU1) {
			NR14_REG = (currentFreq>>8U);
			NR13_REG = currentFreq;
		} else if (synth == PU2) {
			NR24_REG = (currentFreq>>8U);
			NR23_REG = currentFreq;
		} else if (synth == WAV) {
			NR34_REG = (currentFreq>>8U);
			NR33_REG = currentFreq;
		} else {
			NR43_REG = currentFreq;
		}
	}
}

UBYTE vibratoTimer[4];

void updateVibratoPosition(UBYTE synth)
{
	if(vibratoTimer[synth] == vibratoSpeed[synth]) {
		vibratoTimer[synth] = 0x00;
	if(vibratoSlope[synth] && vibratoPosition[synth] < vibratoDepth[synth]) {
		vibratoPosition[synth]+=1;
	} else {
		vibratoSlope[synth] = 0;
		if(vibratoPosition[synth]) {
			vibratoPosition[synth]-=1;
		} else {
			vibratoSlope[synth]=1;
		}
	}
	addVibrato(synth);
	
	}
	vibratoTimer[synth]++;
}
